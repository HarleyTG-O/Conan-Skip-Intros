
Conan exiles Skip Movie Intro


Without Movie is everything but conan exiles movie has nividia and U4
Without Everything is basicly everything
Default


Open the folder where you installed Conan Exiles
Navigate to “Conan Exiles/ConanSndbox/Config/”
Back up your “DefaultGame.ini”
Open “DefaultGame”
Replace with Downloaded File



C:\Program Files (x86)\Steam\steamapps\common\Conan Exiles\ConanSandbox\Config

New .Bat Files to Automate this 